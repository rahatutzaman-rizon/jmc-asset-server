// /models/itemModel.js
// Just a placeholder for item structure - typically handled in the controller for MongoDB
const collectionName = 'items'; // Collection name in MongoDB

module.exports = { collectionName };
